#pragma once
#ifndef INPUT_H
#define INPUT_H

#include <SDL3/SDL.h>

void handleInput(SDL_Event* event);

#endif