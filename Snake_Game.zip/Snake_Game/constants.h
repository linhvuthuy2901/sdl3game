#ifndef CONSTANTS_H
#define CONSTANTS_H

#include <sdl3/sdl.h>

const int GRID_SIZE = 40;
const int WALLSIZE = 7;
const int WINDOW_HEIGHT = 800;
const int WINDOW_WIDTH = 1000;

#endif