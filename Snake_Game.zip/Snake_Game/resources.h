#pragma once

#include "renderer.h"
#include <sdl3/sdl.h>

extern SDL_Window* window;

void initResources();
void cleanupResources();