#include <bits/stdc++.h>
using namespace std;

int main() {
  int n;
  cin >> n;
  int a[n];
  map<int,int> st;
  for (int i=0;i<n;i++)
  {
    cin>>a[i];
    st[a[i]]++;
  }
  int sum=0;
    for(auto x:st)
    {
        if(x.first!=x.second)
        {
            sum+=x.second;
        }
    }
    cout<<sum;
}