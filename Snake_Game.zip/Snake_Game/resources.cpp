﻿#include "resources.h"
#include "game.h"
#include <SDL3_image/SDL_image.h>
#include <SDL3_ttf/SDL_ttf.h>
#include <ctime>


void initResources() {
    if (!SDL_Init(SDL_INIT_VIDEO)) {
        SDL_Log("Error initializing SDL: %s", SDL_GetError());
        return;
    }
    window = SDL_CreateWindow("Snake Game - INT2215_7 - 24021548", WINDOW_WIDTH, WINDOW_HEIGHT, NULL);
    if (!window) {
        SDL_Log("Error creating window: %s", SDL_GetError());
        return;
    }
    renderer = SDL_CreateRenderer(window, NULL);
    if (!renderer) {
        SDL_Log("Error creating renderer: %s", SDL_GetError());
        return;
    }
    bmp = SDL_LoadBMP("restart.bmp");
    if (bmp == nullptr) {
        SDL_Log("Error loading restart.bmp: %s", SDL_GetError());
        return;
    }
    srcRect.w = (float)bmp->w;
    srcRect.h = (float)bmp->h;
    SDL_Log("Loaded restart.bmp: %dx%d", bmp->w, bmp->h);
    tex = SDL_CreateTextureFromSurface(renderer, bmp);
    if (tex == nullptr) {
        SDL_Log("Error creating texture: %s", SDL_GetError());
        return;
    }
    bmp2 = SDL_LoadBMP("backgroundsau.bmp");
    if (bmp2 == nullptr) {
        SDL_Log("Error loading backgroundsau.bmp: %s", SDL_GetError());
        return;
    }
    tex2 = SDL_CreateTextureFromSurface(renderer, bmp2);
    if (tex2 == nullptr) {
        SDL_Log("Error creating texture: %s", SDL_GetError());
        return;
    }
    bmp3 = SDL_LoadBMP("batdau.bmp");
    if (bmp3 == nullptr) {
        SDL_Log("Error loading batdau.bmp: %s", SDL_GetError());
        return;
    }
    tex3 = SDL_CreateTextureFromSurface(renderer, bmp3);
    if (tex3 == nullptr) {
        SDL_Log("Error creating texture: %s", SDL_GetError());
        return;
    }
    bmp4 = SDL_LoadBMP("head.bmp");
    if (bmp4 == nullptr) {
        SDL_Log("Error loading head.bmp: %s", SDL_GetError());
        return;
    }
    tex4 = SDL_CreateTextureFromSurface(renderer, bmp4);
    if (tex4 == nullptr) {
        SDL_Log("Error creating texture: %s", SDL_GetError());
        return;
    }
    bmp5 = SDL_LoadBMP("body.bmp");
    if (bmp5 == nullptr) {
        SDL_Log("Error loading body.bmp: %s", SDL_GetError());
        return;
    }
    tex5 = SDL_CreateTextureFromSurface(renderer, bmp5);
    if (tex5 == nullptr) {
        SDL_Log("Error creating texture: %s", SDL_GetError());
        return;
    }
    bmp6 = SDL_LoadBMP("food.bmp");
    if (bmp6 == nullptr) {
        SDL_Log("Error loading food.bmp: %s", SDL_GetError());
        return;
    }
    tex6 = SDL_CreateTextureFromSurface(renderer, bmp6);
    if (tex6 == nullptr) {
        SDL_Log("Error creating texture: %s", SDL_GetError());
        return;
    }
    bmp7 = SDL_LoadBMP("backgroundbandau.bmp");
    if (bmp7 == nullptr) {
        SDL_Log("Error loading backgroundbandau.bmp: %s", SDL_GetError());
        return;
    }
    tex7 = SDL_CreateTextureFromSurface(renderer, bmp7);
    if (tex7 == nullptr) {
        SDL_Log("Error creating texture: %s", SDL_GetError());
        return;
    }
    bmp8 = SDL_LoadBMP("wall.bmp");
    if (bmp8 == nullptr) {
        SDL_Log("Error loading wall.bmp: %s", SDL_GetError());
        return;
    }
    tex8 = SDL_CreateTextureFromSurface(renderer, bmp8);
    if (tex8 == nullptr) {
        SDL_Log("Error creating texture: %s", SDL_GetError());
        return;
    }
    bmp9 = SDL_LoadBMP("wallcodinh.bmp");
    if (bmp9 == nullptr) {
        SDL_Log("Error loading wallcodinh.bmp: %s", SDL_GetError());
        return;
    }
    tex9 = SDL_CreateTextureFromSurface(renderer, bmp9);
    if (tex9 == nullptr) {
        SDL_Log("Error creating texture: %s", SDL_GetError());
        return;
    }
    if (!TTF_Init()) {
        SDL_Log("Cannot initialize TTF: %s", SDL_GetError());
        return;
    }
    // Khởi tạo trạng thái trò chơi
    length = 3; // Chiều dài ban đầu là 3
    body.clear();
    body.push_back({ 40, 40, GRID_SIZE, GRID_SIZE });  // Đầu
    body.push_back({ 40, 80, GRID_SIZE, GRID_SIZE });  // Thân 1
    body.push_back({ 40, 120, GRID_SIZE, GRID_SIZE }); // Thân 2
    srand(time(0));
    Food.x = randomx();
    Food.y = randomy();
    wall.x = randomx();
    wall.y = randomy();
    if (wall.y == body[0].y) {
        wall.y = randomy();
    }
    for (int i = 0; i < WALLSIZE; i++) {
        if (Food.x >= wallx[i] && Food.y >= wally[i] &&
            Food.x <= wallx[i] + wallw[i] && Food.y <= wally[i] + wallh[i]) {
            Food.x = randomx();
            Food.y = randomy();
        }
    }
}

void cleanupResources() {
    SDL_DestroyRenderer(renderer);
    renderer = nullptr;
    SDL_DestroyWindow(window);
    window = nullptr;
    SDL_QuitSubSystem(SDL_INIT_VIDEO);
    SDL_DestroySurface(bmp);
    SDL_DestroyTexture(tex);
    SDL_DestroySurface(bmp2);
    SDL_DestroyTexture(tex2);
    SDL_DestroySurface(bmp3);
    SDL_DestroyTexture(tex3);
    SDL_DestroySurface(bmp4);
    SDL_DestroyTexture(tex4);
    SDL_DestroySurface(bmp5);
    SDL_DestroyTexture(tex5);
    SDL_DestroySurface(bmp6);
    SDL_DestroyTexture(tex6);
    SDL_DestroySurface(bmp7);
    SDL_DestroyTexture(tex7);
    SDL_DestroySurface(bmp8);
    SDL_DestroyTexture(tex8);
    SDL_DestroySurface(bmp9);
    SDL_DestroyTexture(tex9);
    SDL_DestroySurface(scoreSurface);
    SDL_DestroyTexture(scoreTexture);
    SDL_DestroySurface(highScoreSurface);
    SDL_DestroyTexture(highScoreTexture);
    SDL_DestroySurface(LevelSurface);
    SDL_DestroyTexture(LevelTexture);
    TTF_Quit();
}