﻿#include "game.h"
#include <cstdlib>

float wallx[WALLSIZE] = { GRID_SIZE * 8,  GRID_SIZE * 7, GRID_SIZE * 2, GRID_SIZE * 18,
                         GRID_SIZE * 16, GRID_SIZE * 3, GRID_SIZE * 16 };
float wally[WALLSIZE] = { GRID_SIZE * 13, GRID_SIZE * 7,  GRID_SIZE * 4, GRID_SIZE * 2,
                         GRID_SIZE * 8,  GRID_SIZE * 11, GRID_SIZE * 16 };
float wallw[WALLSIZE] = { GRID_SIZE * 1, GRID_SIZE * 10, GRID_SIZE * 1, GRID_SIZE,
                         GRID_SIZE,     GRID_SIZE * 11, GRID_SIZE * 7 };
float wallh[WALLSIZE] = { GRID_SIZE * 5, GRID_SIZE, GRID_SIZE * 4, GRID_SIZE * 8,
                         GRID_SIZE * 7, GRID_SIZE, GRID_SIZE };

int score = 0;
int highScore = 0;
int level = 1;

int increasetime = 30;
int directionwall = false;
int consttime = 150;
int nowtime = 0;
int uplevel = 4;

bool mark = false;
bool gameend = false;
bool click = false;
bool start = true;
bool started = false;
bool vavaotuong = false;

Object Food;
int countf = 0;
int countf2 = 1;
std::vector<Object> body;
Object wall;
Object wallDoNotRun;

Uint32 lastime = 0;
Uint32 lastimeeatfood = 0;
int timedelay = consttime;

int length = 3;
Direction direction = RIGHT;
Direction pendingDirection = RIGHT;

SDL_FRect rw1, rw2, rw3, rw4, rw5, rw6, rw7;
SDL_FRect rectwall[WALLSIZE];

int randomx() { return (rand() % (WINDOW_WIDTH / GRID_SIZE)) * GRID_SIZE; }
int randomy() { return (rand() % (WINDOW_HEIGHT / GRID_SIZE)) * GRID_SIZE; }

void random2() {
    Food.x = randomx();
    Food.y = randomy();
    for (int i = 0; i < WALLSIZE; i++) {
        if (Food.x >= wallx[i] && Food.y >= wally[i] &&
            Food.x <= wallx[i] + wallw[i] && Food.y <= wally[i] + wallh[i]) {
            Food.x = randomx();
            Food.y = randomy();
        }
    }
}

void touch() {
    random2();
    score += 10;
    if (score > highScore) highScore = score;
}