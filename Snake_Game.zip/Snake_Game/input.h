#pragma once

#include "game.h"
#include <sdl3/sdl.h>

void handleInput(SDL_Event* event);