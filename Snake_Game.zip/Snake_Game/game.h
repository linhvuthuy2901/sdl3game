#ifndef GAME_H
#define GAME_H

#include "constants.h"
#include <vector>
#include <string>

extern float wallx[WALLSIZE];
extern float wally[WALLSIZE];
extern float wallw[WALLSIZE];
extern float wallh[WALLSIZE];

extern int score;
extern int highScore;
extern int level;

extern int increasetime;
extern int directionwall;
extern int consttime;
extern int nowtime;
extern int uplevel;

extern bool mark;
extern bool gameend;
extern bool click;
extern bool start;
extern bool started;
extern bool vavaotuong;

typedef struct {
    int x, y;
    int w, h;
} Object;

extern Object Food;
extern int countf;
extern int countf2;
extern std::vector<Object> body;
extern Object wall;
extern Object wallDoNotRun;

extern Uint32 lastime;
extern Uint32 lastimeeatfood;
extern int timedelay;

extern int length;
enum Direction { LEFT, RIGHT, UP, DOWN };
extern Direction direction;
extern Direction pendingDirection;

extern SDL_FRect rw1, rw2, rw3, rw4, rw5, rw6, rw7;
extern SDL_FRect rectwall[WALLSIZE];

int randomx();
int randomy();
void random2();
void touch();

#endif