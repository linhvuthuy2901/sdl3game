﻿#include "renderer.h"
#include <string>

SDL_Renderer* renderer = nullptr;
SDL_Texture* tex = nullptr;
SDL_Surface* bmp = nullptr;
SDL_Texture* tex2 = nullptr;
SDL_Surface* bmp2 = nullptr;
SDL_Texture* tex3 = nullptr;
SDL_Surface* bmp3 = nullptr;
SDL_Texture* tex4 = nullptr;
SDL_Surface* bmp4 = nullptr;
SDL_Texture* tex5 = nullptr;
SDL_Surface* bmp5 = nullptr;
SDL_Texture* tex6 = nullptr;
SDL_Surface* bmp6 = nullptr;
SDL_Texture* tex7 = nullptr;
SDL_Surface* bmp7 = nullptr;
SDL_Texture* tex8 = nullptr;
SDL_Surface* bmp8 = nullptr;
SDL_Texture* tex9 = nullptr;
SDL_Surface* bmp9 = nullptr;
SDL_Texture* tex10 = nullptr;
SDL_Surface* bmp10 = nullptr;

SDL_Surface* scoreSurface = nullptr;
SDL_Texture* scoreTexture = nullptr;
SDL_Surface* highScoreSurface = nullptr;
SDL_Texture* highScoreTexture = nullptr;
SDL_Surface* LevelSurface = nullptr;
SDL_Texture* LevelTexture = nullptr;

SDL_FRect destRect = { 310.0f, 450.0f, 370.0f, 300.0f };
SDL_FRect srcRect = { 0.0f, 0.0f, 0.0f, 0.0f };
SDL_FRect destRect2 = { 400.0f, 300.0f, 200.0f, 100.0f };

int toadox = 0;
int toadoy = 0;

void food() {
    SDL_SetRenderDrawColor(renderer, 0, 255, 0, 255);
    SDL_FRect rect3 = { (float)Food.x, (float)Food.y, (float)GRID_SIZE, (float)GRID_SIZE };
    SDL_RenderTexture(renderer, tex6, NULL, &rect3);
}

void drawwall() {
    SDL_SetRenderDrawColor(renderer, 139, 69, 19, 255);
    SDL_FRect rect3 = { (float)wall.x, (float)wall.y, (float)GRID_SIZE, (float)GRID_SIZE };
    SDL_RenderTexture(renderer, tex8, NULL, &rect3);
}

void drawwallDoNotRun() {
    for (int i = 0; i < WALLSIZE; i++) {
        rectwall[i] = { wallx[i], wally[i], wallw[i], wallh[i] };
        SDL_RenderTexture(renderer, tex9, NULL, &rectwall[i]);
    }
}


void restartGame() {
    if (tex) {
        SDL_RenderTexture(renderer, tex, &srcRect, &destRect2);
        SDL_Log("Rendering restart texture at %.0f, %.0f", destRect2.x, destRect2.y);
    }
    else {
        SDL_Log("Texture is null!");
    }
    SDL_RenderPresent(renderer);
}