#include "Snake.h"

Snake::Snake(int x, int y, int gridSize) : gridSize(gridSize), currentDirection(RIGHT) {
    SDL_Rect head = {x, y, gridSize, gridSize};
    body.push_back(head); // Đầu rắn
    for (int i = 1; i < 3; i++) {
        SDL_Rect segment = {x, y, gridSize, gridSize}; // Thân ban đầu cùng vị trí
        body.push_back(segment);
    }
}

void Snake::move() {
    for (size_t i = body.size() - 1; i > 0; i--) {
        body[i] = body[i - 1]; // Di chuyển các đoạn thân
    }

    switch (currentDirection) {
        case UP:
            body[0].y -= gridSize;
            break;
        case DOWN:
            body[0].y += gridSize;
            break;
        case LEFT:
            body[0].x -= gridSize;
            break;
        case RIGHT:
            body[0].x += gridSize;
            break;
    }

    // Xử lý xuyên biên
    if (body[0].x < 0) body[0].x = 1000 - gridSize; // WINDOW_WIDTH = 1000
    else if (body[0].x >= 1000) body[0].x = 0;
    if (body[0].y < 0) body[0].y = 800 - gridSize; // WINDOW_HEIGHT = 800
    else if (body[0].y >= 800) body[0].y = 0;
}

void Snake::grow() {
    SDL_Rect newSegment = body.back();
    body.push_back(newSegment);
}

void Snake::changeDirection(Direction dir) {
    if ((dir == UP && currentDirection != DOWN) ||
        (dir == DOWN && currentDirection != UP) ||
        (dir == LEFT && currentDirection != RIGHT) ||
        (dir == RIGHT && currentDirection != LEFT)) {
        currentDirection = dir;
    }
}

void Snake::render(SDL_Renderer* renderer, SDL_Texture* headTexture, SDL_Texture* bodyTexture) {
    for (size_t i = 0; i < body.size(); i++) {
        SDL_FRect rect = {(float)body[i].x, (float)body[i].y, (float)gridSize, (float)gridSize};
        SDL_RenderTexture(renderer, i == 0 ? headTexture : bodyTexture, NULL, &rect);
    }
}

SDL_Rect Snake::getHead() const {
    return body[0];
}

bool Snake::checkCollisionWithWall(const float wallx[], const float wally[], const float wallw[], const float wallh[], int wallSize, int movingWallX, int movingWallY) {
    // Tường cố định
    for (int i = 0; i < wallSize; i++) {
        if (body[0].x >= wallx[i] && body[0].x < wallx[i] + wallw[i] &&
            body[0].y >= wally[i] && body[0].y < wally[i] + wallh[i]) {
            return true;
        }
    }

    // Tường di động
    if (body[0].x == movingWallX && body[0].y == movingWallY) {
        return true;
    }

    return false;
}

bool Snake::checkCollisionWithSelf() {
    for (size_t i = 3; i < body.size(); i++) {
        if (body[0].x == body[i].x && body[0].y == body[i].y) {
            return true;
        }
    }
    return false;
}

std::vector<SDL_Rect>& Snake::getBody() {
    return body;
}

Direction Snake::getDirection() const {
    return currentDirection;
}

void Snake::fastMove() {
    grow(); // Tăng chiều dài để giữ số đoạn
    for (size_t i = body.size() - 1; i > 0; i--) {
        body[i] = body[i - 1];
    }
    if (currentDirection == UP && body[0].y > 3 * gridSize) {
        body[0].y -= 3 * gridSize;
    } else if (currentDirection == DOWN && body[0].y < 800 - 3 * gridSize) {
        body[0].y += 3 * gridSize;
    } else if (currentDirection == RIGHT && body[0].x < 1000 - 2 * gridSize) {
        body[0].x += 3 * gridSize;
    } else if (currentDirection == LEFT && body[0].x > 3 * gridSize) {
        body[0].x -= 3 * gridSize;
    }
}