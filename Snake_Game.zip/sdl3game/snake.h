#ifndef SNAKE_H
#define SNAKE_H

#include <SDL3/SDL.h>
#include <SDL3_image/SDL_image.h>
#include <SDL3_ttf/SDL_ttf.h>
#include <vector>
#include <string>

const int GRID_SIZE = 40;
const int WALLSIZE = 7;
const int WINDOW_HEIGHT = 800;
const int WINDOW_WIDTH = 1000;

extern float wallx[];
extern float wally[];
extern float wallw[];
extern float wallh[];

extern SDL_Window *window;
extern SDL_Renderer *renderer;
extern SDL_Texture *tex, *tex2, *tex3, *tex4, *tex5, *tex6, *tex7, *tex8, *tex9, *tex10;
extern SDL_Surface *bmp, *bmp2, *bmp3, *bmp4, *bmp5, *bmp6, *bmp7, *bmp8, *bmp9, *bmp10;
extern SDL_Surface *scoreSurface, *highScoreSurface, *LevelSurface;
extern SDL_Texture *scoreTexture, *highScoreTexture, *LevelTexture;

extern SDL_FRect destRect, srcRect, destRect2;
extern int increasetime, directionwall, consttime, nowtime, uplevel;
extern int score, highScore, level;

extern int toadox, toadoy;

typedef struct {
    int x, y;
    int w, h;
} Object;

extern bool mark, gameend, click, start, started, vavaotuong;
extern Object Food;
extern int countf, countf2;
extern std::vector<Object> body;
extern Object wall, wallDoNotRun;

extern Uint32 lastime, lastimeeatfood;
extern int timedelay, length;

enum Direction { LEFT, RIGHT, UP, DOWN };
extern Direction direction, pendingDirection;

int randomx();
int randomy();
void food();
void restartGame();
void drawwall();
void drawwallDoNotRun();
void drawphuthuy();
void random2();
void touch();

#endif