    #include <bits/stdc++.h>
    #include <functional>
    #include <vector>
    const long long MOD=1e9+7;
    using namespace std;
    int main() {
    int n;
    cin >> n;
    char a[n];
    for (int i = 0; i < n; i++) {
        cin >> a[i];
    }
    sort(a,a+n);
    string tmp1="";
    for (int i = 0; i < n; i++) {
        tmp1+=a[i];
    }
    int x1=stoi(tmp1);
    if(n!=1)
    {
        swap(a[0],a[1]);

    }
    string tmp2="";
    for (int i = 0; i < n; i++) {
        tmp2+=a[i];
    }
    int x2=stoi(tmp2);
    cout<<x1+x2;
    }