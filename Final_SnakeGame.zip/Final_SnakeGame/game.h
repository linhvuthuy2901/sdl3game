#ifndef GAME_H
#define GAME_H

#include <vector>
#include <string>
#include <SDL3/SDL.h>

const int GRID_SIZE = 40;
const int WINDOW_HEIGHT = 800;
const int WINDOW_WIDTH = 1000;

typedef struct {
    int x, y;
    int w, h;
} Object;

enum Direction { LEFT, RIGHT, UP, DOWN };
extern int foodCount;
extern int foodSinceLastBullet;
extern std::vector<Object> body;
extern Object Food;
extern Object Dan;
extern int score;
extern int highScore;
extern int level;
extern int toadox, toadoy;
extern bool gameend;
extern bool start;
extern bool started;
extern bool vavaotuong;
extern Uint32 lasttimebullet; 
extern bool mark;
extern bool click;
extern bool bullet;
extern int countf;
extern int countf2;
extern int length;
extern int trudiem;
extern Direction direction;
extern Direction pendingDirection;
extern Uint32 lastime;
extern Uint32 lastimeeatfood;
extern bool quanlihuongtrai;
extern bool quanlihuongphai;
extern bool quanlihuongtren;
extern bool quanlihuongduoi;
extern int timedelay;
extern int uplevel;
extern int consttime;
extern int increasetime;
extern bool nextlevel;
extern bool lv1;
extern bool lv2;
void random2();
void touch();
void updateSnake();
void restartGameLogic();
void dandichuyen();
void drawbullet(); 

#endif